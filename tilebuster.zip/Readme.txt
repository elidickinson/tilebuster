Greetings!

The game is loosely based on my recollection of an old TI calculator game called Diamonds.

That 10k limit really snuck up on me. I had intended to do a high score list using localStorage and a "share custom map on twitter" using AJAX, but just ran out of bytes. At least I didn't have to resort to implementing LZW compression in javascript for the map data (thought about it...). Happy to share the unpacked code, but it's embarassingly messy.

Cheers,
Eli